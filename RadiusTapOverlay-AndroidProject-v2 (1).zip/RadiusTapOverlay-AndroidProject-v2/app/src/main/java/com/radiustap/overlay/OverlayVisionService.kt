package com.radiustap.overlay

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class OverlayVisionService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_LEAD_MS = "lead_ms"
        const val EXTRA_RADIUS_RATIO = "radius_ratio"
        private const val CHANNEL_ID = "radiustap_overlay_channel"
        private const val NOTIF_ID = 101
    }

    private lateinit var windowManager: WindowManager
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var visionThread: HandlerThread? = null
    private var visionHandler: Handler? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var ringView: RingOverlayView? = null
    private var ringParams: WindowManager.LayoutParams? = null
    private var controlBar: LinearLayout? = null
    private var controlParams: WindowManager.LayoutParams? = null
    private var toggleBtn: Button? = null

    private var screenWidth = 1080
    private var screenHeight = 2400
    private var screenDensity = 420

    @Volatile
    private var isRunning = false

    private var leadOffsetMs = 38.0
    private var ringRadiusRatio = 0.345
    private val cooldownMs = 320L

    private var prevDotAngle: Double? = null
    private var prevTimestampNs: Long? = null
    private var lastTapElapsedMs = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY

        leadOffsetMs = intent.getDoubleExtra(EXTRA_LEAD_MS, 38.0)
        ringRadiusRatio = intent.getDoubleExtra(EXTRA_RADIUS_RATIO, 0.345)

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION")
        val resultData: Intent? = intent.getParcelableExtra(EXTRA_RESULT_DATA)

        if (resultCode != Activity.RESULT_OK || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        setupOverlays()
        setupMediaProjection(resultCode, resultData)
        return START_STICKY
    }

    private fun setupOverlays() {
        if (ringView != null) return

        val radiusPx = (screenWidth * ringRadiusRatio).toFloat()
        val overlayBoxSize = (radiusPx * 2.3f).toInt().coerceAtMost(screenWidth)

        ringView = RingOverlayView(this).apply {
            ringRadiusPx = radiusPx
            isActive = false
        }

        // Non-touchable visual reticle so game touches pass right through it
        ringParams = WindowManager.LayoutParams(
            overlayBoxSize,
            overlayBoxSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenWidth - overlayBoxSize) / 2
            y = ((screenHeight * 0.455) - overlayBoxSize / 2.0).toInt()
        }
        windowManager.addView(ringView, ringParams)

        // Draggable floating control pill (Drag handle + Start/Stop + Close)
        controlBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.argb(215, 24, 26, 32))
            setPadding(16, 10, 16, 10)
        }

        val dragBtn = Button(this).apply {
            text = "✥ Move"
            textSize = 12f
        }

        toggleBtn = Button(this).apply {
            text = "START"
            textSize = 12f
            setOnClickListener {
                isRunning = !isRunning
                prevDotAngle = null
                prevTimestampNs = null
                ringView?.isActive = isRunning
                text = if (isRunning) "PAUSE" else "START"
            }
        }

        val closeBtn = Button(this).apply {
            text = "✕"
            textSize = 12f
            setOnClickListener {
                stopSelf()
            }
        }

        controlBar?.addView(dragBtn)
        controlBar?.addView(toggleBtn)
        controlBar?.addView(closeBtn)

        controlParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 140
        }

        // Dragging "Move" repositions both the floating bar and the target ring
        dragBtn.setOnTouchListener(object : View.OnTouchListener {
            private var initialControlX = 0
            private var initialControlY = 0
            private var initialRingX = 0
            private var initialRingY = 0
            private var touchStartX = 0f
            private var touchStartY = 0f

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                val cp = controlParams ?: return false
                val rp = ringParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialControlX = cp.x
                        initialControlY = cp.y
                        initialRingX = rp.x
                        initialRingY = rp.y
                        touchStartX = event.rawX
                        touchStartY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchStartX).toInt()
                        val dy = (event.rawY - touchStartY).toInt()
                        cp.x = initialControlX + dx
                        cp.y = initialControlY + dy
                        rp.x = initialRingX + dx
                        rp.y = initialRingY + dy
                        windowManager.updateViewLayout(controlBar, cp)
                        windowManager.updateViewLayout(ringView, rp)
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(controlBar, controlParams)
    }

    private fun setupMediaProjection(resultCode: Int, resultData: Intent) {
        visionThread = HandlerThread("RadiusTapVisionThread").apply { start() }
        visionHandler = Handler(visionThread!!.looper)

        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(resultCode, resultData)

        imageReader = ImageReader.newInstance(
            screenWidth,
            screenHeight,
            PixelFormat.RGBA_8888,
            2
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                if (!isRunning) return@setOnImageAvailableListener

                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * screenWidth

                val bitmap = Bitmap.createBitmap(
                    screenWidth + rowPadding / pixelStride,
                    screenHeight,
                    Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)
                processFrame(bitmap)
                bitmap.recycle()
            } finally {
                image.close()
            }
        }, visionHandler)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "RadiusTapScreen",
            screenWidth,
            screenHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            visionHandler
        )
    }

    private fun processFrame(bitmap: Bitmap) {
        val rp = ringParams ?: return
        val rv = ringView ?: return

        val cx = rp.x + (rp.width / 2)
        val cy = rp.y + (rp.height / 2)
        val radius = rv.ringRadiusPx.toInt()

        val (targetAngle, dotAngle) = sampleRingAngles(bitmap, cx, cy, radius, 360)
        if (targetAngle == null || dotAngle == null) return

        val nowNs = SystemClock.elapsedRealtimeNanos()
        val prevAngle = prevDotAngle
        val prevNs = prevTimestampNs

        if (prevAngle != null && prevNs != null) {
            val dtSec = ((nowNs - prevNs) / 1_000_000_000.0).coerceAtLeast(1e-4)
            val omega = shortestAngularDiff(dotAngle, prevAngle) / dtSec
            val predictedDot = dotAngle + omega * (leadOffsetMs / 1000.0)
            val delta = abs(shortestAngularDiff(targetAngle, predictedDot))

            val nowMs = SystemClock.elapsedRealtime()
            if (delta < Math.toRadians(6.5) && (nowMs - lastTapElapsedMs) > cooldownMs) {
                val tapX = (cx + radius * cos(targetAngle)).toFloat()
                val tapY = (cy + radius * sin(targetAngle)).toFloat()
                lastTapElapsedMs = nowMs

                mainHandler.post {
                    val service = TapAccessibilityService.instance
                    if (service != null) {
                        service.performTap(tapX, tapY)
                    } else {
                        Toast.makeText(
                            this,
                            "Enable RadiusTap Accessibility Service!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }

        prevDotAngle = dotAngle
        prevTimestampNs = nowNs

        mainHandler.post {
            rv.lastTargetAngleRad = targetAngle
            rv.lastDotAngleRad = dotAngle
            rv.invalidate()
        }
    }

    private fun sampleRingAngles(
        bitmap: Bitmap,
        cx: Int,
        cy: Int,
        radius: Int,
        samples: Int
    ): Pair<Double?, Double?> {
        val w = bitmap.width
        val h = bitmap.height
        val hsv = FloatArray(3)
        val whiteIndices = ArrayList<Int>()

        for (i in 0 until samples) {
            val angle = (2.0 * PI * i) / samples
            val x = (cx + radius * cos(angle)).toInt().coerceIn(0, w - 1)
            val y = (cy + radius * sin(angle)).toInt().coerceIn(0, h - 1)

            val pixel = bitmap.getPixel(x, y)
            Color.colorToHSV(pixel, hsv)
            // Match Python logic: S < 55/255 (~0.216) and V > 215/255 (~0.843)
            if (hsv[1] < (55f / 255f) && hsv[2] > (215f / 255f)) {
                whiteIndices.add(i)
            }
        }

        if (whiteIndices.isEmpty()) return Pair(null, null)

        val clusters = ArrayList<MutableList<Int>>()
        var current = mutableListOf(whiteIndices[0])
        for (idx in 1 until whiteIndices.size) {
            val v = whiteIndices[idx]
            if (v == current.last() + 1) {
                current.add(v)
            } else {
                clusters.add(current)
                current = mutableListOf(v)
            }
        }
        clusters.add(current)

        if (clusters.size > 1 && clusters.first().first() == 0 && clusters.last().last() == samples - 1) {
            val merged = ArrayList<Int>(clusters.last().size + clusters.first().size)
            merged.addAll(clusters.last())
            merged.addAll(clusters.first())
            clusters[0] = merged
            clusters.removeAt(clusters.size - 1)
        }

        clusters.sortByDescending { it.size }
        val targetCluster = clusters[0]
        val targetAngle = Math.toRadians(targetCluster.average() * (360.0 / samples))

        val dotAngle = if (clusters.size >= 2) {
            Math.toRadians(clusters[1].average() * (360.0 / samples))
        } else {
            null
        }

        return Pair(targetAngle, dotAngle)
    }

    private fun shortestAngularDiff(a: Double, b: Double): Double {
        var diff = (a - b + PI) % (2.0 * PI)
        if (diff < 0) diff += 2.0 * PI
        return diff - PI
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "RadiusTap Vision Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("RadiusTap Overlay Active")
            .setContentText("Align green ring over target and tap START")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .build()
    }

    override fun onDestroy() {
        isRunning = false
        ringView?.let { runCatching { windowManager.removeView(it) } }
        controlBar?.let { runCatching { windowManager.removeView(it) } }
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        visionThread?.quitSafely()
        super.onDestroy()
    }
}
