package com.radiustap.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class RingOverlayView(context: Context) : View(context) {

    var ringRadiusPx: Float = 250f
        set(value) {
            field = value
            invalidate()
        }

    var isActive: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var lastTargetAngleRad: Double? = null
    var lastDotAngleRad: Double? = null

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = Color.argb(190, 0, 230, 118)
    }

    private val centerDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(200, 0, 230, 118)
    }

    private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(230, 255, 214, 0)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f

        ringPaint.color = if (isActive) {
            Color.argb(210, 0, 230, 118)
        } else {
            Color.argb(180, 255, 171, 0)
        }

        canvas.drawCircle(cx, cy, ringRadiusPx, ringPaint)
        canvas.drawCircle(cx, cy, 10f, centerDotPaint)

        lastTargetAngleRad?.let { angle ->
            val tx = cx + (ringRadiusPx * Math.cos(angle)).toFloat()
            val ty = cy + (ringRadiusPx * Math.sin(angle)).toFloat()
            canvas.drawCircle(tx, ty, 12f, markerPaint)
        }
    }
}
