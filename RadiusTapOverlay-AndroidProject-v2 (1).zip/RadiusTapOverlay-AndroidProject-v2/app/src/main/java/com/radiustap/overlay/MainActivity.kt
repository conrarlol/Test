package com.radiustap.overlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var leadMs = 38.0
    private var radiusRatio = 0.345

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, OverlayVisionService::class.java).apply {
                putExtra(OverlayVisionService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(OverlayVisionService.EXTRA_RESULT_DATA, result.data)
                putExtra(OverlayVisionService.EXTRA_LEAD_MS, leadMs)
                putExtra(OverlayVisionService.EXTRA_RADIUS_RATIO, radiusRatio)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            moveTaskToBack(true)
        } else {
            Toast.makeText(this, "Screen capture permission is required to read the ring.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnOverlayPerm = findViewById<Button>(R.id.btnOverlayPerm)
        val btnAccessPerm = findViewById<Button>(R.id.btnAccessPerm)
        val btnLaunchOverlay = findViewById<Button>(R.id.btnLaunchOverlay)
        val btnStopOverlay = findViewById<Button>(R.id.btnStopOverlay)

        val leadLabel = findViewById<TextView>(R.id.leadLabel)
        val leadSeekBar = findViewById<SeekBar>(R.id.leadSeekBar)
        val radiusLabel = findViewById<TextView>(R.id.radiusLabel)
        val radiusSeekBar = findViewById<SeekBar>(R.id.radiusSeekBar)

        leadSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                leadMs = progress.toDouble()
                leadLabel.text = "Lead Offset: $progress ms"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        radiusSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val safeProgress = progress.coerceAtLeast(100)
                radiusRatio = safeProgress / 1000.0
                radiusLabel.text = "Ring Radius: ${safeProgress / 10.0}% of screen width"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnOverlayPerm.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Overlay permission already granted!", Toast.LENGTH_SHORT).show()
            }
        }

        btnAccessPerm.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find 'RadiusTap Overlay' and turn it ON.", Toast.LENGTH_LONG).show()
        }

        btnLaunchOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Please complete Step 1 (Overlay Permission) first.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (TapAccessibilityService.instance == null) {
                Toast.makeText(this, "Please complete Step 2 (Enable Accessibility Service) first.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
        }

        btnStopOverlay.setOnClickListener {
            stopService(Intent(this, OverlayVisionService::class.java))
        }
    }
}
